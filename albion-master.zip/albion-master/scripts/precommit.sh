#!/bin/sh
pytest